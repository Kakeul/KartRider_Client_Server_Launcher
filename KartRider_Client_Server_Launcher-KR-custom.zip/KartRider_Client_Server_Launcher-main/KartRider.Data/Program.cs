using KartLibrary.Consts;
using KartLibrary.Data;
using KartLibrary.File;
using KartLibrary.Xml;
using KartRider.IO.Packet;
using Microsoft.Win32;
using Profile;
using LoggerLibrary;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Linq;
using System.Xml.Linq;
using System.Globalization;
using System.Threading.Tasks;
using KartRider.Common.Data;
using KartRider.Common.Security;

namespace KartRider
{
    internal static class Program
    {
        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool AllocConsole();

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern IntPtr GetConsoleWindow();

        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        public const int SW_HIDE = 0;
        public const int SW_SHOW = 5;
        public static bool isVisible = true;
        public static readonly IntPtr consoleHandle = GetConsoleWindow();

        public static Launcher LauncherDlg;
        public static Setting SettingDlg;
        public static bool SpeedPatch;
        public static bool PreventItem;
        public static Encoding targetEncoding = Encoding.UTF8;

        [STAThread]
        private static async Task Main(string[] args)
        {
            // 分配控制台
            AllocConsole();

            // 保存原始输出流
            var originalOut = Console.Out;

            // 创建缓存编写器并替换控制台输出（stdout + stderr 都拦截）
            CachedConsoleWriter.cachedWriter = new CachedConsoleWriter(originalOut);
            Console.SetOut(CachedConsoleWriter.cachedWriter);
            Console.SetError(CachedConsoleWriter.cachedWriter);

            // 注册未处理异常：进程终止前立即保存日志并弹窗阻塞
            AppDomain.CurrentDomain.UnhandledException += (sender, args) =>
            {
                CachedConsoleWriter.ForceSaveAndClear();

                var ex = args.ExceptionObject as Exception;
                string message = ex?.ToString() ?? args.ExceptionObject?.ToString() ?? "未知错误";

                MessageBox.Show(
                    $"程序发生未处理的异常，日志已保存。\n\n{message}",
                    "致命错误",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );

                Environment.Exit(1);
            };

            // 初始化自适应编码
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            SetAdaptiveConsoleEncoding();

            // 自更新后由新实例启动：清理旧版本备份文件，随后继续正常主流程
            bool isUpdatedRestart = args != null && args.Length > 0 && string.Equals(args[0], "/updated", StringComparison.OrdinalIgnoreCase);
            if (isUpdatedRestart)
            {
                Update.CleanupOldVersion();
            }

            if (args != null && args.Length > 0 && !isUpdatedRestart)
            {
                RhoPacker.PackTool(args);
            }
            else
            {
                ProfileService.LoadSettings();
                // 检查更新：AutoUpdate 开启时静默更新，关闭时弹窗提示
                await Update.UpdateDataAsync(ProfileService.SettingConfig.AutoUpdate);
                // 사용자가 설정에서 선택한 클라이언트를 우선 사용합니다.
                // 최초 실행처럼 경로가 비어 있으면 기존 레지스트리 경로를 한 번만 가져옵니다.
                string RootDirectory = "";
                if (!string.IsNullOrWhiteSpace(ProfileService.SettingConfig.ClientPath))
                {
                    string configuredExe = Path.GetFullPath(ProfileService.SettingConfig.ClientPath);
                    RootDirectory = Path.GetDirectoryName(configuredExe) ?? "";
                }
                else
                {
                    string TCGame = "HKEY_CURRENT_USER\\Software\\TCGame\\kart";
                    string registryDirectory = (string)Registry.GetValue(TCGame, "gamepath", null);
                    if (!string.IsNullOrWhiteSpace(registryDirectory))
                    {
                        string registryExe = Path.Combine(registryDirectory, "KartRider.exe");
                        if (File.Exists(registryExe))
                        {
                            RootDirectory = Path.GetFullPath(registryDirectory);
                            ProfileService.SettingConfig.ClientPath = registryExe;
                            ProfileService.SaveSettings();
                        }
                    }
                }

                if (string.IsNullOrWhiteSpace(RootDirectory) ||
                    !File.Exists(Path.Combine(RootDirectory, "KartRider.exe")) ||
                    !File.Exists(Path.Combine(RootDirectory, "KartRider.pin")))
                {
                    MessageBox.Show(
                        "사용할 카트라이더 클라이언트를 찾을 수 없습니다.\n\n설정에서 KartRider.exe를 선택해 주세요.",
                        "클라이언트 설정 필요",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                RootDirectory = Path.GetFullPath(RootDirectory);
                string KartRider = Path.Combine(RootDirectory, "KartRider.exe");
                string pinFile = Path.Combine(RootDirectory, "KartRider.pin");
                string pinFileBak = Path.Combine(RootDirectory, "KartRider-bak.pin");
                if (!string.IsNullOrEmpty(RootDirectory))
                {
                    if (File.Exists(pinFileBak))
                    {
                        File.Delete(pinFile);
                        File.Move(pinFileBak, pinFile);
                    }

                    Load_Data();

                    try
                    {
                        // ServerIP는 클라이언트가 접속할 주소이고, 서버는 이 PC에서 실행합니다.
                        RouterListener.Start();
                    }
                    catch (System.Net.Sockets.SocketException ex)
                    {
                        MessageBox.Show(
                            $"서버 포트를 열 수 없습니다.\n\n포트: {ProfileService.SettingConfig.ServerPort}\n원인: {ex.Message}",
                            "서버 시작 실패", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        RouterListener.Stop();
                        return;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"서버 리스너 시작 실패: {ex.Message}");
                        RouterListener.Stop();
                        return;
                    }

                    PatchManager.StartUpdateAsync(RootDirectory).Wait();

                    PINFile val = new PINFile(pinFile);
                    ProfileService.SettingConfig.ClientVersion = val.Header.MinorVersion;
                    ProfileService.SettingConfig.LocaleID = val.Header.LocaleID;
                    ProfileService.SettingConfig.nClientLoc = val.Header.Unk2;
                    ProfileService.SaveSettings();

                    if (!ProfileService.SettingConfig.Console)
                    {
                        ShowWindow(consoleHandle, SW_HIDE);
                        isVisible = false;
                    }
                    if (ProfileService.SettingConfig.EnableMod)
                    {
                        // 初始化ModManager
                        ModManager.Initialize(FileName.appDir);
                    }

                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    Launcher StartLauncher = new Launcher();
                    Program.LauncherDlg = StartLauncher;
                    Program.LauncherDlg.kartRiderDirectory = RootDirectory;
                    Launcher.KartRider = KartRider;
                    Launcher.pinFile = pinFile;
                    Launcher.pinFileBak = pinFileBak;
                    Application.Run(StartLauncher);
                }
            }
        }

        public static void LoadClientMetadata(string rootDirectory)
        {
            string pinPath = Path.Combine(rootDirectory, "KartRider.pin");
            if (!File.Exists(pinPath))
                throw new FileNotFoundException("선택한 클라이언트에 KartRider.pin이 없습니다.", pinPath);

            PINFile val = new PINFile(pinPath);
            ProfileService.SettingConfig.ClientVersion = val.Header.MinorVersion;
            ProfileService.SettingConfig.LocaleID = val.Header.LocaleID;
            ProfileService.SettingConfig.nClientLoc = val.Header.Unk2;
            ProfileService.SaveSettings();
        }

        public static void SetAdaptiveConsoleEncoding()
        {
            try
            {
                // 1. 检测操作系统类型
                bool isWindows = RuntimeInformation.IsOSPlatform(OSPlatform.Windows);

                // 2. 优先尝试 UTF-8（跨平台通用）
                targetEncoding = Encoding.UTF8;

                // 3. Windows 中文环境特殊处理（部分终端默认 GBK）
                if (isWindows)
                {
                    try
                    {
                        // 注册表路径
                        string codePageRegPath = "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Nls\\CodePage";

                        // 读取 OEMCP 值（返回 object 类型，需判断是否为 null）
                        object oemcpObj = Registry.GetValue(codePageRegPath, "OEMCP", null);

                        // 正确判断：是否读取到有效值，且能转换为 int
                        if (oemcpObj != null && int.TryParse(oemcpObj.ToString(), out int oemcp))
                        {
                            try
                            {
                                // 获取对应编码
                                targetEncoding = Encoding.GetEncoding(oemcp);
                            }
                            catch (ArgumentException)
                            {
                                // 编码不支持时回退到 UTF-8
                                targetEncoding = Encoding.UTF8;
                            }
                        }
                        else
                        {
                            // 未读取到 OEMCP 值
                            targetEncoding = Encoding.UTF8;
                        }
                    }
                    catch (Exception ex)
                    {
                        // 捕获注册表读取异常（如权限不足）
                        targetEncoding = Encoding.UTF8;
                    }
                }
                // 4. 应用编码设置（输出/输入保持一致）
                Console.OutputEncoding = targetEncoding;
                Console.InputEncoding = targetEncoding;

                // 5. 验证编码是否生效（可选）
                Console.WriteLine($"적용된 인코딩: {targetEncoding.EncodingName}");
            }
            catch (Exception ex)
            {
                // 异常时使用系统默认编码作为最后保障
                Console.WriteLine($"인코딩 설정 실패, 기본 인코딩 사용: {ex.Message}");
            }
        }

        public static void Load_Data()
        {
            try
            {
                string localFilePath = FileName.ModelMax_LoadFile;
                
                // 确保目录存在
                string directory = Path.GetDirectoryName(localFilePath);
                if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                // 如果本地文件不存在，直接创建
                if (!File.Exists(localFilePath))
                {
                    File.WriteAllText(localFilePath, ModelMax.XmlContent);
                    Console.WriteLine($"ModelMax.xml 생성 완료: {localFilePath}");
                }
                else
                {
                    // 加载本地和资源XML
                    XDocument localXml = XDocument.Load(localFilePath);
                    XDocument resourceXml = XDocument.Parse(ModelMax.XmlContent);
                    
                    int addedCount = 0;
                    
                    // 遍历资源中的所有 kart 节点
                    foreach (var resourceKart in resourceXml.Root!.Elements("kart"))
                    {
                        string? id = resourceKart.Attribute("id")?.Value;
                        string? name = resourceKart.Attribute("name")?.Value;
                        
                        if (id != null)
                        {
                            // 检查本地是否已存在该ID
                            bool exists = localXml.Root!.Elements("kart")
                                .Any(k => k.Attribute("id")?.Value == id);
                            
                            if (!exists)
                            {
                                // 复制 kart 元素（包含所有属性）
                                localXml.Root.Add(new XElement(resourceKart));
                                Console.WriteLine($"kart 추가: {name ?? id}");
                                addedCount++;
                            }
                        }
                    }
                    
                    if (addedCount > 0)
                    {
                        localXml.Save(localFilePath, SaveOptions.None);
                        Console.WriteLine($"ModelMax.xml 업데이트 완료, 추가: {addedCount} 个kart");
                    }
                    else
                    {
                        Console.WriteLine("ModelMax.xml이 최신 상태입니다.");
                    }
                }

                SpecialKartConfig.SaveConfigToFile(FileName.SpecialKartConfig);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"데이터 로드 실패: {ex.Message}");
            }
        }
    }
}