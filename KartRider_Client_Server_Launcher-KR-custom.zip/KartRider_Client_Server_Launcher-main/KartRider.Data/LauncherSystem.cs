using KartLibrary.File;
using KartRider.Common.Data;
using KartRider.IO.Packet;
using Profile;
using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KartRider
{
	public static class LauncherSystem
	{
		public static void MessageBoxType1()
		{
			MessageBox.Show("카트라이더가 이미 실행 중입니다!", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
		}

		public static void MessageBoxType2()
		{
			MessageBox.Show("이미 실행 중인 런처가 있습니다!\n런처를 동시에 여러 개 실행할 수 없습니다!\n확인을 눌러 프로그램을 종료하세요.", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
			Environment.Exit(1);
		}

		public static void MessageBoxType3(string RootDirectory)
		{
			DialogResult result = MessageBox.Show(
				"找不到游戏文件！\n点击确认下载游戏文件到本程序目录，取消结束程序",
				"确认操作",
				MessageBoxButtons.OKCancel,
				MessageBoxIcon.Question);
			
			if (result == DialogResult.OK)
			{
				// 使用本程序目录作为游戏目录进行下载
				string currentDirectory = AppDomain.CurrentDomain.BaseDirectory;
                if (string.IsNullOrEmpty(RootDirectory))
				{
                    CheckGame(currentDirectory);
                }
				else
				{
                    CheckGame(RootDirectory);
                }
            }
			else
			{
				Environment.Exit(1);
			}
		}

		public static async Task CheckGameAsync(string kartRiderDirectory, string updateUrl = "")
		{
			// 强制显示终端窗口
            bool wasVisible = Program.isVisible;
            if (!Program.isVisible)
            {
                Program.isVisible = true;
                Program.ShowWindow(Program.consoleHandle, Program.SW_SHOW);
            }

			try
			{
				string filePath = JsonHelper.GetFilePath();
				if (string.IsNullOrEmpty(updateUrl))
				{
					var data = await Update.GetUpdateAsync().ConfigureAwait(false);
					if (data != null)
					{
						updateUrl = data.update_prefix;
					}
					else
					{
						MessageBox.Show("게임 버전을 가져오지 못했습니다!", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
					}
				}
				await new PatchManager().StartPatchAsync(updateUrl, kartRiderDirectory).ConfigureAwait(false);

				PINFile val = new PINFile(Path.GetFullPath(Path.Combine(kartRiderDirectory, @"KartRider.pin")));
				ProfileService.SettingConfig.ClientVersion = val.Header.MinorVersion;
				ProfileService.SettingConfig.LocaleID = val.Header.LocaleID;
				ProfileService.SettingConfig.nClientLoc = val.Header.Unk2;
				ProfileService.SaveSettings();
				// 更新完成后，根据设置恢复终端显示状态
				if (!wasVisible && !ProfileService.SettingConfig.Console)
				{
					Program.isVisible = false;
					Program.ShowWindow(Program.consoleHandle, Program.SW_HIDE);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show($"업데이트 중 오류가 발생했습니다:{ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		public static void CheckGame(string kartRiderDirectory, string updateUrl = "", bool single = true)
		{
			Exception capturedException = null;

			// 在新线程中运行异步操作，避免阻塞 UI 线程
			var thread = new Thread(() =>
			{
				try
				{
					Console.WriteLine("[CheckGame] 업데이트 스레드 시작");
					CheckGameAsync(kartRiderDirectory, updateUrl).GetAwaiter().GetResult();
					Console.WriteLine("[CheckGame] 업데이트 스레드 완료");
				}
				catch (Exception ex)
				{
					Console.WriteLine($"[CheckGame] 업데이트 스레드 오류: {ex.GetType().Name}: {ex.Message}");
					Console.WriteLine($"[CheckGame] 스택: {ex.StackTrace}");
					capturedException = ex;
				}
			})
			{
				IsBackground = false, // 改为前台线程，确保异常能被捕获
				Name = "GameUpdateThread"
			};

			Console.WriteLine("[CheckGame] 스레드 시작");
			thread.Start();
			Console.WriteLine("[CheckGame] 스레드 완료 대기...");
			thread.Join(); // 스레드 완료 대기
			Console.WriteLine("[CheckGame] 스레드 종료");

			if (capturedException != null)
			{
				MessageBox.Show($"업데이트 중 오류가 발생했습니다:{capturedException.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			else
			{
				if (single)
				{
					PatchManager.RhoDump(kartRiderDirectory);
				}
			}
		}
	}
}