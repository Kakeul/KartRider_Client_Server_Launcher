using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace KartRider
{
    partial class Setting
    {
        private void InitializeComponent()
        {
            Proxy_comboBox = new ComboBox();
            Proxy_label = new Label();
            AiSpeed_comboBox = new ComboBox();
            AiSpeed_label = new Label();
            Speed_comboBox = new ComboBox();
            Speed_label = new Label();
            Version_comboBox = new ComboBox();
            Version_label = new Label();
            PlayerName = new TextBox();
            Name_label = new Label();
            ClientPath = new TextBox();
            ClientPath_label = new Label();
            BrowseClient_Button = new Button();
            ServerIP = new TextBox();
            IP_label = new Label();
            ServerPort = new TextBox();
            Port_label = new Label();
            NgsOn = new CheckBox();
            SoloRank = new CheckBox();
            EnableMod = new CheckBox();
            AutoUpdate = new CheckBox();
            SuspendLayout();
            // 
            // PlayerName
            // 
            PlayerName.Location = new System.Drawing.Point(68, 20);
            PlayerName.Name = "PlayerName";
            PlayerName.Size = new System.Drawing.Size(114, 23);
            PlayerName.TabIndex = 1;
            // 
            // Name_label
            // 
            Name_label.AutoSize = true;
            Name_label.ForeColor = System.Drawing.Color.Blue;
            Name_label.Location = new System.Drawing.Point(19, 24);
            Name_label.Name = "Name_label";
            Name_label.Size = new System.Drawing.Size(30, 12);
            Name_label.Text = "닉네임:";
            // 
            // ClientPath
            ClientPath.Location = new System.Drawing.Point(68, 49);
            ClientPath.Name = "ClientPath";
            ClientPath.Size = new System.Drawing.Size(165, 23);
            ClientPath.TabIndex = 2;
            // 
            // ClientPath_label
            ClientPath_label.AutoSize = true;
            ClientPath_label.ForeColor = System.Drawing.Color.Blue;
            ClientPath_label.Location = new System.Drawing.Point(19, 53);
            ClientPath_label.Name = "ClientPath_label";
            ClientPath_label.Size = new System.Drawing.Size(48, 12);
            ClientPath_label.Text = "클라이언트:";
            // 
            // BrowseClient_Button
            BrowseClient_Button.Location = new System.Drawing.Point(236, 49);
            BrowseClient_Button.Name = "BrowseClient_Button";
            BrowseClient_Button.Size = new System.Drawing.Size(65, 23);
            BrowseClient_Button.TabIndex = 3;
            BrowseClient_Button.Text = "찾아보기";
            BrowseClient_Button.UseVisualStyleBackColor = true;
            BrowseClient_Button.Click += BrowseClient_Button_Click;
            // 
            // ServerIP
            // 
            ServerIP.Location = new System.Drawing.Point(68, 78);
            ServerIP.Name = "ServerIP";
            ServerIP.Size = new System.Drawing.Size(114, 23);
            ServerIP.TabIndex = 4;
            ServerIP.Text = "127.0.0.1";
            // 
            // IP_label
            // 
            IP_label.AutoSize = true;
            IP_label.ForeColor = System.Drawing.Color.Blue;
            IP_label.Location = new System.Drawing.Point(19, 82);
            IP_label.Name = "IP_label";
            IP_label.Size = new System.Drawing.Size(30, 12);
            IP_label.Text = "IP:";
            // 
            // ServerPort
            // 
            ServerPort.Location = new System.Drawing.Point(68, 107);
            ServerPort.Name = "ServerPort";
            ServerPort.Size = new System.Drawing.Size(114, 23);
            ServerPort.TabIndex = 5;
            ServerPort.Text = "39311";
            // 
            // Port_label
            // 
            Port_label.AutoSize = true;
            Port_label.ForeColor = System.Drawing.Color.Blue;
            Port_label.Location = new System.Drawing.Point(19, 111);
            Port_label.Name = "Port_label";
            Port_label.Size = new System.Drawing.Size(30, 12);
            Port_label.Text = "포트:";
            // 
            // Version_comboBox
            // 
            Version_comboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            Version_comboBox.ForeColor = System.Drawing.Color.Red;
            Version_comboBox.FormattingEnabled = true;
            Version_comboBox.Location = new System.Drawing.Point(68, 136);
            Version_comboBox.Name = "Version_comboBox";
            Version_comboBox.Size = new System.Drawing.Size(114, 23);
            Version_comboBox.TabIndex = 6;
            // 
            // Version_label
            // 
            Version_label.AutoSize = true;
            Version_label.ForeColor = System.Drawing.Color.Blue;
            Version_label.Location = new System.Drawing.Point(19, 140);
            Version_label.Name = "Version_label";
            Version_label.Size = new System.Drawing.Size(30, 12);
            Version_label.Text = "버전:";
            // 
            // Speed_comboBox
            // 
            Speed_comboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            Speed_comboBox.ForeColor = System.Drawing.Color.Red;
            Speed_comboBox.FormattingEnabled = true;
            Speed_comboBox.Location = new System.Drawing.Point(68, 165);
            Speed_comboBox.Name = "Speed_comboBox";
            Speed_comboBox.Size = new System.Drawing.Size(114, 23);
            Speed_comboBox.TabIndex = 7;
            // 
            // Speed_label
            // 
            Speed_label.AutoSize = true;
            Speed_label.ForeColor = System.Drawing.Color.Blue;
            Speed_label.Location = new System.Drawing.Point(19, 169);
            Speed_label.Name = "Speed_label";
            Speed_label.Size = new System.Drawing.Size(30, 12);
            Speed_label.Text = "속도:";
            // 
            // AiSpeed_comboBox
            // 
            AiSpeed_comboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            AiSpeed_comboBox.ForeColor = System.Drawing.Color.Red;
            AiSpeed_comboBox.FormattingEnabled = true;
            AiSpeed_comboBox.Location = new System.Drawing.Point(68, 194);
            AiSpeed_comboBox.Name = "AiSpeed_comboBox";
            AiSpeed_comboBox.Size = new System.Drawing.Size(114, 23);
            AiSpeed_comboBox.TabIndex = 8;
            // 
            // AiSpeed_label
            // 
            AiSpeed_label.AutoSize = true;
            AiSpeed_label.ForeColor = System.Drawing.Color.Blue;
            AiSpeed_label.Location = new System.Drawing.Point(19, 198);
            AiSpeed_label.Name = "AiSpeed_label";
            AiSpeed_label.Size = new System.Drawing.Size(30, 12);
            AiSpeed_label.Text = "AI 속도:";
            // 
            // Proxy_comboBox
            // 
            Proxy_comboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            Proxy_comboBox.ForeColor = System.Drawing.Color.Red;
            Proxy_comboBox.FormattingEnabled = true;
            Proxy_comboBox.Location = new System.Drawing.Point(68, 223);
            Proxy_comboBox.Name = "Proxy_comboBox";
            Proxy_comboBox.Size = new System.Drawing.Size(114, 23);
            Proxy_comboBox.TabIndex = 9;
            // 
            // Proxy_label
            // 
            Proxy_label.AutoSize = true;
            Proxy_label.ForeColor = System.Drawing.Color.Blue;
            Proxy_label.Location = new System.Drawing.Point(19, 227);
            Proxy_label.Name = "Proxy_label";
            Proxy_label.Size = new System.Drawing.Size(30, 12);
            Proxy_label.Text = "프록시:";
            // 
            // NgsOn
            // 
            NgsOn.AutoSize = true;
            NgsOn.ForeColor = System.Drawing.Color.Blue;
            NgsOn.Location = new System.Drawing.Point(190, 140);
            NgsOn.Name = "NgsOn";
            NgsOn.Size = new System.Drawing.Size(52, 16);
            NgsOn.TabIndex = 10;
            NgsOn.Text = "NgsOn";
            NgsOn.UseVisualStyleBackColor = true;
            // 
            // SoloRank
            // 
            SoloRank.AutoSize = true;
            SoloRank.ForeColor = System.Drawing.Color.Blue;
            SoloRank.Location = new System.Drawing.Point(190, 169);
            SoloRank.Name = "SoloRank";
            SoloRank.Size = new System.Drawing.Size(52, 16);
            SoloRank.TabIndex = 11;
            SoloRank.Text = "솔로 랭크";
            SoloRank.UseVisualStyleBackColor = true;
            // 
            // EnableMod
            // 
            EnableMod.AutoSize = true;
            EnableMod.ForeColor = System.Drawing.Color.Blue;
            EnableMod.Location = new System.Drawing.Point(190, 198);
            EnableMod.Name = "EnableMod";
            EnableMod.Size = new System.Drawing.Size(52, 16);
            EnableMod.TabIndex = 12;
            EnableMod.Text = "MOD 사용";
            EnableMod.UseVisualStyleBackColor = true;
            // 
            // AutoUpdate
            // 
            AutoUpdate.AutoSize = true;
            AutoUpdate.ForeColor = System.Drawing.Color.Blue;
            AutoUpdate.Location = new System.Drawing.Point(190, 227);
            AutoUpdate.Name = "AutoUpdate";
            AutoUpdate.Size = new System.Drawing.Size(52, 16);
            AutoUpdate.TabIndex = 13;
            AutoUpdate.Text = "자동 업데이트";
            AutoUpdate.UseVisualStyleBackColor = true;
            // 
            // Setting
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new System.Drawing.Size(315, 260);
            Controls.Add(BrowseClient_Button);
            Controls.Add(ClientPath);
            Controls.Add(ClientPath_label);
            Controls.Add(PlayerName);
            Controls.Add(Name_label);
            Controls.Add(ServerIP);
            Controls.Add(IP_label);
            Controls.Add(ServerPort);
            Controls.Add(Port_label);
            Controls.Add(Speed_comboBox);
            Controls.Add(Speed_label);
            Controls.Add(Version_comboBox);
            Controls.Add(Version_label);
            Controls.Add(AiSpeed_comboBox);
            Controls.Add(AiSpeed_label);
            Controls.Add(Proxy_comboBox);
            Controls.Add(Proxy_label);
            Controls.Add(NgsOn);
            Controls.Add(SoloRank);
            Controls.Add(EnableMod);
            Controls.Add(AutoUpdate);
            Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 134);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Icon = Icon.ExtractAssociatedIcon(Process.GetCurrentProcess().MainModule.FileName);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Setting";
            StartPosition = FormStartPosition.CenterParent;
            Text = "설정";
            FormClosing += OnFormClosing;
            Load += OnLoad;
            ResumeLayout(false);
            PerformLayout();
        }

        private TextBox PlayerName;
        private TextBox ClientPath;
        private Button BrowseClient_Button;
        private Label ClientPath_label;
        private TextBox ServerIP;
        private TextBox ServerPort;
        private ComboBox Speed_comboBox;
        private ComboBox Version_comboBox;
        private ComboBox AiSpeed_comboBox;
        private ComboBox Proxy_comboBox;
        private CheckBox NgsOn;
        private CheckBox SoloRank;
        private CheckBox EnableMod;
        private CheckBox AutoUpdate;
        private Label Name_label;
        private Label IP_label;
        private Label Port_label;
        private Label Speed_label;
        private Label Version_label;
        private Label AiSpeed_label;
        private Label Proxy_label;
    }
}