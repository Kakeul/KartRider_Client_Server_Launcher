using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using ExcData;
using Profile;

namespace KartRider
{
    public partial class Setting : Form
    {
        public string[] AiSpeed = new string[] { "쉬움", "어려움", "지옥" };

        private static readonly Dictionary<string, string> VersionDisplayNames = new Dictionary<string, string>
        {
            ["国服"] = "중국 서버",
            ["国服复古"] = "중국 서버 (레트로)",
            ["韩服复古"] = "한국 서버 (레트로)"
        };

        private static readonly Dictionary<string, string> SpeedDisplayNames = new Dictionary<string, string>
        {
            ["标准"] = "표준", ["真无限"] = "진 무한", ["慢速S0"] = "느린 S0",
            ["普通S1"] = "일반 S1", ["快速S2"] = "빠른 S2", ["高速S3"] = "고속 S3",
            ["新手"] = "초보", ["初级"] = "초급", ["L3"] = "L3", ["L2"] = "L2",
            ["L1"] = "L1", ["Pro"] = "Pro"
        };

        private static string DisplayVersion(string value) => VersionDisplayNames.TryGetValue(value, out string display) ? display : value;
        private static string InternalVersion(string value) => VersionDisplayNames.FirstOrDefault(x => x.Value == value).Key ?? value;
        private static string DisplaySpeed(string value) => SpeedDisplayNames.TryGetValue(value, out string display) ? display : value;
        private static string InternalSpeed(string value) => SpeedDisplayNames.FirstOrDefault(x => x.Value == value).Key ?? value;
        private static string DisplayAiSpeed(string value) => value switch { "简单" => "쉬움", "困难" => "어려움", "地狱" => "지옥", _ => value };
        private static string InternalAiSpeed(string value) => value switch { "쉬움" => "简单", "어려움" => "困难", "지옥" => "地狱", _ => value };

        public string[] urls = new string[] { "https://v6.gh-proxy.org/", "https://gh-proxy.com/", "https://cdn.gh-proxy.org/", "https://ghproxy.net/", "https://git.myany.uk/", "" };

        public Setting()
        {
            InitializeComponent();
        }

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (!ushort.TryParse(ServerPort.Text, out ushort serverPort) || serverPort == 0 || serverPort > ushort.MaxValue - 2)
            {
                MessageBox.Show("서버 포트는 1~65533 사이의 숫자여야 합니다.", "설정 오류", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                e.Cancel = true;
                return;
            }

            string selectedClient = ClientPath.Text.Trim();
            if (string.IsNullOrWhiteSpace(selectedClient) || !File.Exists(selectedClient) ||
                !string.Equals(Path.GetFileName(selectedClient), "KartRider.exe", StringComparison.OrdinalIgnoreCase) ||
                !File.Exists(Path.Combine(Path.GetDirectoryName(Path.GetFullPath(selectedClient))!, "KartRider.pin")))
            {
                MessageBox.Show("KartRider.exe와 같은 폴더에 KartRider.pin이 있는 클라이언트를 선택해 주세요.", "클라이언트 설정 오류", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                e.Cancel = true;
                return;
            }

            string newDirectory = Path.GetDirectoryName(Path.GetFullPath(selectedClient))!;
            string oldDirectory = Program.LauncherDlg?.kartRiderDirectory ?? "";
            bool clientChanged = !string.Equals(oldDirectory, newDirectory, StringComparison.OrdinalIgnoreCase);
            bool serverChanged = ServerIP.Text.Trim() != ProfileService.SettingConfig.ServerIP || serverPort != ProfileService.SettingConfig.ServerPort;

            ProfileService.SettingConfig.Name = PlayerName.Text;
            ProfileService.SettingConfig.ServerIP = ServerIP.Text.Trim();
            ProfileService.SettingConfig.ServerPort = serverPort;
            ProfileService.SettingConfig.ClientPath = Path.GetFullPath(selectedClient);
            ProfileService.SettingConfig.NgsOn = NgsOn.Checked;
            ProfileService.SettingConfig.SoloRank = SoloRank.Checked;
            ProfileService.SettingConfig.EnableMod = EnableMod.Checked;
            ProfileService.SettingConfig.AutoUpdate = AutoUpdate.Checked;
            ProfileService.SaveSettings();

            if (Program.LauncherDlg != null && clientChanged)
            {
                try
                {
                    Program.LoadClientMetadata(newDirectory);
                    Program.LauncherDlg.kartRiderDirectory = newDirectory;
                    Launcher.KartRider = Path.Combine(newDirectory, "KartRider.exe");
                    Launcher.pinFile = Path.Combine(newDirectory, "KartRider.pin");
                    Launcher.pinFileBak = Path.Combine(newDirectory, "KartRider-bak.pin");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"클라이언트 정보를 읽지 못했습니다.\n\n{ex.Message}", "클라이언트 오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    e.Cancel = true;
                    return;
                }
            }

            if (serverChanged || clientChanged)
            {
                RouterListener.Stop();
                try
                {
                    RouterListener.Start();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"LAN 서버를 다시 시작하지 못했습니다.\n\n{ex.Message}", "서버 시작 실패", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    e.Cancel = true;
                }
            }
        }

        private void OnLoad(object sender, EventArgs e)
        {
            ProfileService.LoadSettings();
            PlayerName.Text = ProfileService.SettingConfig.Name;
            ServerIP.Text = ProfileService.SettingConfig.ServerIP;
            ServerPort.Text = ProfileService.SettingConfig.ServerPort.ToString();
            ClientPath.Text = ProfileService.SettingConfig.ClientPath;
            NgsOn.Checked = ProfileService.SettingConfig.NgsOn;
            SoloRank.Checked = ProfileService.SettingConfig.SoloRank;
            EnableMod.Checked = ProfileService.SettingConfig.EnableMod;
            AutoUpdate.Checked = ProfileService.SettingConfig.AutoUpdate;
            foreach (string key in SpeedType.speedNames[ProfileService.SettingConfig.Version].Keys)
            {
                Speed_comboBox.Items.Add(DisplaySpeed(key));
            }
            foreach (string key in SpeedType.speedNames.Keys)
            {
                Version_comboBox.Items.Add(DisplayVersion(key));
            }
            foreach (string key in AiSpeed)
            {
                AiSpeed_comboBox.Items.Add(key);
            }
            foreach (string key in urls)
            {
                Proxy_comboBox.Items.Add(key);
            }
            string currentSpeed = SpeedType.speedNames[ProfileService.SettingConfig.Version].FirstOrDefault(x => x.Value == ProfileService.SettingConfig.SpeedType).Key;
            Speed_comboBox.Text = DisplaySpeed(currentSpeed);
            Speed_comboBox.SelectedIndexChanged += Speed_comboBox_SelectedIndexChanged;
            Version_comboBox.Text = DisplayVersion(ProfileService.SettingConfig.Version);
            Version_comboBox.SelectedIndexChanged += Version_comboBox_SelectedIndexChanged;
            AiSpeed_comboBox.Text = DisplayAiSpeed(ProfileService.SettingConfig.AiSpeedType);
            AiSpeed_comboBox.SelectedIndexChanged += AiSpeed_comboBox_SelectedIndexChanged;
            Proxy_comboBox.Text = ProfileService.SettingConfig.Proxy;
            Proxy_comboBox.SelectedIndexChanged += Proxy_comboBox_SelectedIndexChanged;
        }

        private void BrowseClient_Button_Click(object sender, EventArgs e)
        {
            using OpenFileDialog dialog = new OpenFileDialog
            {
                Title = "카트라이더 클라이언트 선택",
                Filter = "KartRider 실행 파일 (KartRider.exe)|KartRider.exe|실행 파일 (*.exe)|*.exe",
                CheckFileExists = true,
                Multiselect = false
            };

            if (!string.IsNullOrWhiteSpace(ClientPath.Text) && File.Exists(ClientPath.Text))
                dialog.InitialDirectory = Path.GetDirectoryName(Path.GetFullPath(ClientPath.Text));

            if (dialog.ShowDialog(this) == DialogResult.OK)
                ClientPath.Text = dialog.FileName;
        }

        private void Version_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Version_comboBox.SelectedItem != null)
            {
                string selectedVersion = InternalVersion(Version_comboBox.SelectedItem.ToString());
                if (SpeedType.speedNames.ContainsKey(selectedVersion))
                {
                    ProfileService.SettingConfig.Version = selectedVersion;
                    Speed_comboBox.Items.Clear();
                    foreach (string key in SpeedType.speedNames[selectedVersion].Keys)
                    {
                        Speed_comboBox.Items.Add(DisplaySpeed(key));
                    }
                    if (Speed_comboBox.Items.Count > 0)
                    {
                        Speed_comboBox.SelectedIndex = 0;
                        ProfileService.SettingConfig.SpeedType = SpeedType.speedNames[selectedVersion][InternalSpeed(Speed_comboBox.Text)];
                    }
                    ProfileService.SaveSettings();
                }
                else
                {
                    Console.WriteLine("잘못된 속도 유형이 선택되었습니다.");
                }
            }
        }

        private void Speed_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Speed_comboBox.SelectedItem != null)
            {
                string selectedSpeed = InternalSpeed(Speed_comboBox.SelectedItem.ToString());
                if (SpeedType.speedNames[ProfileService.SettingConfig.Version].ContainsKey(selectedSpeed))
                {
                    ProfileService.SettingConfig.SpeedType = SpeedType.speedNames[ProfileService.SettingConfig.Version][selectedSpeed];
                    ProfileService.SaveSettings();
                }
                else
                {
                    Console.WriteLine("잘못된 속도 유형이 선택되었습니다.");
                }
            }
        }

        private void AiSpeed_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (AiSpeed_comboBox.SelectedItem != null)
            {
                string selectedAiSpeed = AiSpeed_comboBox.SelectedItem.ToString();
                string internalAiSpeed = InternalAiSpeed(selectedAiSpeed);
                if (AiSpeed.Contains(selectedAiSpeed))
                {
                    ProfileService.SettingConfig.AiSpeedType = internalAiSpeed;
                    ProfileService.SaveSettings();
                }
                else
                {
                    Console.WriteLine("잘못된 AI 속도가 선택되었습니다.");
                }
            }
        }

        private void Proxy_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Proxy_comboBox.SelectedItem != null)
            {
                string selectedProxy = Proxy_comboBox.SelectedItem.ToString();
                if (urls.Contains(selectedProxy))
                {
                    ProfileService.SettingConfig.Proxy = selectedProxy;
                    ProfileService.SaveSettings();
                }
                else
                {
                    Console.WriteLine("잘못된 프록시가 선택되었습니다.");
                }
            }
        }
    }
}
