using System;
using System.CodeDom;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using KartRider.Common.Network;
using Profile;

namespace KartRider
{
    public class RouterListener
    {
        public static string ServerIP = "";

        public static TcpListener Listener { get; private set; }

        public static SessionGroup MySession { get; set; }

        public static List<string> RouterIPList = new List<string>();

        public static MsgrServer MsgrServer { get; private set; }

        public static UdpServer UDPServer { get; private set; }

        public static UdpServer P2PServer { get; private set; }

        public static int DataTime()
        {
            DateTime dt = DateTime.Now;
            // DateTime time = new DateTime(1900, 1, 1, 0, 0, 0);
            // TimeSpan t = dt.Subtract(time);
            // double totalSeconds = dt.TimeOfDay.TotalSeconds / 4;
            int MonthCount = (dt.Year - 1900) * 12 + dt.Month;
            int oddMonthCount = (MonthCount + 1) / 2;
            return oddMonthCount;
        }

        public static void OnAcceptSocket(IAsyncResult ar)
        {
            try
            {
                if (RouterListener.Listener == null)
                    return;

                Socket clientSocket = RouterListener.Listener.EndAcceptSocket(ar);

                // 创建客户端会话（自动开始接收消息）
                RouterListener.MySession = new SessionGroup(clientSocket, null);

                // 将会话添加到管理类
                ClientManager.AddClient(RouterListener.MySession);
            }
            catch (ObjectDisposedException)
            {
                // Listener 已停止/释放，忽略
            }
            catch (NullReferenceException)
            {
                // Listener 已被 Stop() 置为 null，忽略
            }
            catch (Exception ex)
            {
                Console.WriteLine($"예외 발생:{ex.Message}");
            }
            finally
            {
                if (RouterListener.Listener != null)
                {
                    try
                    {
                        RouterListener.Listener.BeginAcceptSocket(new AsyncCallback(RouterListener.OnAcceptSocket), null);
                    }
                    catch (ObjectDisposedException) { }
                    catch (NullReferenceException) { }
                }
            }
        }

        public static void Start()
        {
            ushort port = ProfileService.SettingConfig.ServerPort;
            if (port == 0 || port > ushort.MaxValue - 2)
                throw new ArgumentOutOfRangeException(nameof(port), "서버 포트는 1~65533 범위여야 합니다.");

            if (UDPServer == null || P2PServer == null || MsgrServer == null)
            {
                UDPServer = new UdpServer("UDP", port);
                P2PServer = new UdpServer("P2P", (ushort)(port + 1));
                MsgrServer = new MsgrServer("MsgrServer", (ushort)(port + 2));
            }

            // 현재 설정된 포트로 서버를 시작합니다.
            UDPServer.Start();
            P2PServer.Start();
            MsgrServer.Start();

            // 仅在 Listener 为 null 或未绑定时才需要创建/启动
            if (RouterListener.Listener == null || !RouterListener.Listener.Server.IsBound)
            {
                // 先收集 IP 列表（在创建 Listener 之前完成，避免中间异常导致
                // Listener 处于"已创建但未 Start"状态，进而在 Stop() 时触发
                // .NET 8 的 "Not listening" InvalidOperationException）
                RouterIPList = new List<string>();
                RouterIPList = LanIpGetter.GetAllLocalLanIps();
                RouterIPList.Add("127.0.0.1");
                foreach (var IP in RouterIPList)
                {
                    Console.WriteLine("Load Server IP: {0}:{1}", IP, ProfileService.SettingConfig.ServerPort);
                }

                // 后台异步获取公网 IP，避免 .Result 同步阻塞服务器启动
                // （GetCountryAsync 若网络不可达可能耗时数秒~数十秒，期间玩家将无法连接）
                Task.Run(async () =>
                {
                    try
                    {
                        var ipInfo = await Update.GetCountryAsync();
                        string ip = ipInfo?.Ip ?? "";
                        if (!string.IsNullOrEmpty(ip))
                        {
                            lock (RouterIPList)
                            {
                                if (!RouterIPList.Contains(ip))
                                {
                                    RouterIPList.Add(ip);
                                }
                            }
                            RouterListener.ServerIP = ip;
                            Console.WriteLine("Load Server IP: {0}:{1}", ip, ProfileService.SettingConfig.ServerPort);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"공인 IP를 가져오지 못했습니다: {ex.Message}");
                    }
                });

                // 创建 Listener 后立即 Start，避免中间代码抛异常导致不一致状态
                RouterListener.Listener = new TcpListener(IPAddress.Any, port);
                RouterListener.Listener.Start();
                RouterListener.Listener.BeginAcceptSocket(OnAcceptSocket, RouterListener.Listener);
            }
            else
            {
                RouterListener.Listener.BeginAcceptSocket(OnAcceptSocket, RouterListener.Listener);
            }
            if (LanIpGetter.CheckHasPublicIpv6())
            {
                TinyMapper.Start();
            }

            // 启动心跳/掉线检测监控，及时清理假死连接（幽灵玩家）
            HeartbeatMonitor.Start();
        }

        /// <summary>
        /// 停止服务端所有监听（释放端口）
        /// </summary>
        public static void Stop()
        {
            // 停止 UDP 服务
            UDPServer?.Stop();
            P2PServer?.Stop();

            // TCP 메시지 서버 중지
            MsgrServer?.Stop();

            // 停止 TCP 监听器
            // 注意：.NET 8 中 TcpListener.Stop() 在未 Start 时会抛出
            // "Not listening. You must call the Start method before calling this method."
            // 使用 Server.Close() 直接关闭底层 Socket 避免此异常。
            if (Listener != null)
            {
                try
                {
                    if (Listener.Server != null)
                    {
                        Listener.Server.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[RouterListener] TCP 리스너 중지 중 오류: {ex.Message}");
                }
                Listener = null;
            }

            // 停止 TinyMapper 端口转发
            TinyMapper.Stop();

            // 停止心跳/掉线检测监控
            HeartbeatMonitor.Stop();

            UDPServer = null;
            P2PServer = null;
            MsgrServer = null;

            Console.WriteLine("[RouterListener] 모든 서버가 중지되었습니다.");
        }
    }
}